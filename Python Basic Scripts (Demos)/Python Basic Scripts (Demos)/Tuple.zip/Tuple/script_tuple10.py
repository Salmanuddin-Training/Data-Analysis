#Iterating Through a Tuple
# Output: 
# Hello John
# Hello Kate
for name in ('John','Kate'):
     print("Hello",name)    